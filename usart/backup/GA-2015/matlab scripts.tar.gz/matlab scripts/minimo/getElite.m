function [popElite plebe] = getElite(populacao,txElitismo)
    [N l] = size(populacao);
    
    tam = round(N*txElitismo);
    popElite = [];
    for i = 1:tam
        popElite = [popElite; populacao(i,:)];
    end
    plebe = [];
    for i = tam + 1 : N
        plebe = [plebe; populacao(i,:)];
    end
end