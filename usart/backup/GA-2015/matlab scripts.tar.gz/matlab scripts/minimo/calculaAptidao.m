function aptidao = calculaAptidao(valorCromossomo)           
    
    [N l] = size(valorCromossomo);
    
    aptidao = zeros(N,1);    
    for i = 1:N
        val = f(valorCromossomo(i));
        aptidao(i) = val;
    end    
end