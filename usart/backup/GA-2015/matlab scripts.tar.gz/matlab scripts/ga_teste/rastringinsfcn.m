function z = my_fun(x)
    z = 20 + x^2 + x^2 - 10*(cos(2*pi*x) + cos(2*pi*x));
end