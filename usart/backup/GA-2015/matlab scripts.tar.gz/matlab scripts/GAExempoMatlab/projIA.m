
clear

%Par�metros que podem ser alterados
tFinal = 2*60; % Tempo final de simula��o
tmC = 400; %Torque do motor Nm
trC = 1; %Transmiss�o valor entre 0.5 e 2

%d = [0 3000 6000 9000 12000 15000 18000];%Pontos em metros da pista que ter�o inclina��es
%vtheta = [0 5 0 5 0 -10 0] *(pi/180);%Inclina��es

vtheta = [10] *(pi/180); %Inclina��es
d = [0];

step = 0.1; %Passo de simula��o

%Par�metros que n�o podem ser alterados
t = [0:step:tFinal];
x = zeros(1,length(t));%Velocidade do ve�culo em m/s
sAux = zeros(1,length(t)); %Vetor auxiliar
s = zeros(1,length(t));  %Dist�ncia em metros
enTemp = zeros(1,length(t));  %Vetor auxiliar
E = 0; %Energia gasta em kWh
theta = zeros(1,length(t)); %Valores de inclina��o

tm = ones(1,length(t))*tmC;
tr = ones(1,length(t))*trC;


for k=2:length(t)
    [x(k),enTemp(k)]=vehicleRun(tm(k-1),tr(k-1),theta(k-1),x(k-1),enTemp(k-1),t(k-1),t(k));
    [theta(k),s(k),sAux(k)]=vehiclePista(x(k),sAux(k-1),t(k-1),t(k),vtheta,d);
    disp(t(k));
    
    
    xref = 50;
    erro(k) = xref - x(k);
    result = outra_funcao_aqui();%evalfis([erro(k) theta(k)],data);%func(x(k),xref,theta(k));
    tm(k) =  tm(k-1) + result(1);
    tr(k) = .7;%result(2);
    
    
    %[tm(k),tr(k)]=func(x(k),xref,theta(k));
end

E = (enTemp(length(t))/3600)/1000;