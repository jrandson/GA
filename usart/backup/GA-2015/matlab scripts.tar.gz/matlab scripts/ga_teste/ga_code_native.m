% ga coding
%http://www.mathworks.com/help/gads/options-and-outputs.html#f16697
%http://www.mathworks.com/help/gads/gaoptimset.html
max = 5;
min = -5;

nvars = 1;
A = [];
b = [];
Aeq = [];
beq = [];
LB = f(min);
UB = f(max);
nonlcon = [];
timeLimit = inf;
nIter = 100;

%options = gaoptimset(@ga)
options = gaoptimset('PopulationType','bitstring','PopulationSize',100);
fvoptions = gaoptimset(options,'EliteCount',0.1,'CrossoverFraction',0.8);
options = gaoptimset(options,'CrossoverFcn',@crossoversinglepoint);
options = gaoptimset(options,'SelectionFcn',@selectionstochunif);
options = gaoptimset(options,'Generations',nIter);
%options = gaoptimset(options,'PlotInterval',10);
options = gaoptimset(options,'PlotFcns',@gaplotbestf);

 

%[x fval] = ga(@f,nvars,[],[],[],[],[],[],[],options);
tic;
[x,fval,exitflag,output,population,scores] = ga(@f,nvars,[],[],[],[],LB,UB,[],options);
time_ga = toc;













