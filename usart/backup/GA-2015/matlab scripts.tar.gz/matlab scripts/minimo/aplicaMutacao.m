function populacaoMutada = aplicaMutacao(populacao)        
    [N l] = size(populacao);
    populacaoMutada = zeros(N,l);
    for j = 1:N
        crm = populacao(j,:);
        k = randi(l);
        if(crm(1,k) == 1)
            crm(1,k) = 0;
        else
            crm(1,k) = 1;
        end
        populacaoMutada(j,:) = crm;
    end 
end