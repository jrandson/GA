function valorPopulacao = getValorCromossomo(populacao,min,max)
    [N l] = size(populacao);
    valorPopulacao = zeros(N,1);
    for i = 1:N
        crm = populacao(i,:);
        d = 0;
        for j = 1:l
            d = d + crm(l+1-j)*2^(j-1);
        end
        %reajusta o valor decimal correspodente para o range do problema
        x = min + (max-min)*d/(2^l - 1);
        valorPopulacao(i) = x;
    end
end