function [x,e]=vehicleRun(tm,tr,theta,xAnt,eAnt,tAnt,tAtual)

%Par�metros do ve�culo
M = 450; %Massa do ve�culo em Kg.
K = 1; %Aparente aumento na massa do ve�culo devido � massa girante interna - valor entre 1.08 e 1.1 
ro = 1.18; %Densidade do ar.
Cd = 0.51; %Coeficiente do atrito aerodin�mico.
Afr = 2.4; %�rea frontal em m^2.
C0 = 0.015; 
C1 = 0;
g = 9.81;%Acelera��o da gravidade na terra.
r = 0.26; %Raio da roda em metros.

fd = sign(xAnt)*(0.5*ro*Cd*Afr*xAnt^2); %Atrito aerodin�mico
fr = sign(xAnt)*(M*g*(C0 + C1*xAnt^2)); %Atrito de rolamento
fg = M*g*sin(theta); %Atrito gravitacional
fa = fd + fr + fg;
ft = tm/r;

Tspan1 = [tAnt tAtual];
IC1 = xAnt;
[aa, xTemp]=ode45(@(t,x) fv(t,x,(1/tr)*ft,fa,M,K),Tspan1,IC1);
x = xTemp(end);

p = ft*x;

Tspan2 = [tAnt tAtual];
IC2 = eAnt;

[bb, eTemp]=ode45(@(t,e) fenerg(t,e,p),Tspan2,IC2);
e = eTemp(end);

end

function xdot=fv(t,x,ft,fa,M,K)
    xdot=(ft-fa)/(M*K);
end

function edot=fenerg(t,e,p)
    edot = p;
end


