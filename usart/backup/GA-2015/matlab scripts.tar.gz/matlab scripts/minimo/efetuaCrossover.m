function novaPopulacao = efetuaCrossover(populacao)
    
    [N l] = size(populacao);
    novaPopulacao = zeros(N,l);
    for k = 1:2:N
        crm1 = populacao(k,:);
        crm2 = populacao(randi(N),:);
        ini = l/2;    
        for i = ini+1:l
            aux = crm1(i);
            crm1(i) = crm2(i);
            crm2(i) = aux;                
        end
        novaPopulacao(k,:) = crm1;
        novaPopulacao(k+1,:) = crm2;
    end    
end