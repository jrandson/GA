% a tx de muta��o inside sobre a popula��o q sobra, e n�o sobre o popula��o
% inicial
function popMuta = getPopulacaoMutada(populacao,txMutacao)
    [N l] = size(populacao);
    
    tam = round(N*txMutacao);
    popMuta = [];
    
    for i = 1:tam
        popMuta =  [popMuta; populacao(i,:)];
    end
    
    popMuta = aplicaMutacao(popMuta);
end