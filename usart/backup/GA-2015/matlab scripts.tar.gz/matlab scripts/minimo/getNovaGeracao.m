function populacao = getNovaGeracao(popCross,popElite,popMuta)
    populacao = [];    
    populacao = [populacao;popCross];
    populacao = [populacao;popElite];
    populacao = [populacao;popMuta];    
end