function y = f(x)
    %y = x.*x + sin(exp(x));
    %y = 5*sin(10 * sin(x*pi/2) + cos(pi*x + 1.6));
    y = x.*sin(x.*5);
    %y = (x - 1) .*(x - 1) + 2;
    %y = abs(x.*sin(10./x));
    %y = exp(-1.*x).*sin(x);    
    %y = -1*(x+1).*(x-7);
    %y = tan(x);
    
end