function z=teste(x,a)
    z = x(1)^2+x(2)^2;
end