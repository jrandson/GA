%http://www.icmc.usp.br/pessoas/andre/research/genetic/

options = gaoptimset(@ga);

options.PopulationType = 'doubleVector'; %tipo dos indiv�duos
options.PopulationSize = 20; %tamanho da popula��o

options.PopInitRange = [0;1]; %Matriz ou vetor que determina o range da popula��o inicial gerada automaticamente

options.EliteCount = 0; %Elitismo
options.CrossoverFraction = 0.8 %Taxa de cruzamento


options.CrossoverFcn = @crossoversinglepoint; %�nico ponto no crossover
options.Generations = 1000;

[x fval exitflag output population scores]=ga(@teste,2,[],[],[],[],[],[],[],options)

for i=1:10     
     options.InitialPopulation = population;
     [x fval exitflag output population scores]=ga(@teste,2,[],[],[],[],[],[],[],options)
     pause
 
 end



