%pseudoc�digo algoritmo gen�tico
l = 8;
N = 10; %100,200,300,...

txCrossover = 0.8; % 70~85%
txMutacao = 1; % 0.1 ~10% A muta��o inside sobre a populacao que sobra
txElitismo = .1; % 0 ~ 10%;

nIter =100;
min = -5;
max = 5;

fval = 0;
populacao = randi([0,1],N,l);

%1. inicializa uma populacao aleatoria
%2.avalia populacao
%   2.1.1 calcula o score de cada individui
%   2.1.2 converte para o intervalo do range definido
%2.2. seleciona os pais para o crossover baseado na aptidao
%2.3.Seleciona os melhores individuos para participarem da proxima gera��o
    %sem cruzar - elitismo
%2.4.Seleciona os menos aptos para sofrefem mutacao
%2.5.aplica o crossover nos pais selecionados para compor a populacao seguinte
%2.6.Obtem a nova gera��o: filhos + elite + mutantes

record = [];
t = 0;
time = [];


fval_ant = 0;

precisao = 10^-6;
erro = 1;


while( t < nIter)
    t = t+1;
    disp(t);    
    tic;
    populacao = ordenaPopulacao(populacao,min,max);
    
    [popElite populacao] = getElite(populacao,txElitismo);
    
    [populacaoCruzada populacao] = getPopulacaoCruzada(populacao,txCrossover);    
    
    popMuta = getPopulacaoMutada(populacao,txMutacao);
    
    populacao = getNovaGeracao(populacaoCruzada,popElite,popMuta);
           
    fval = avaliaPopulacao(populacao,min,max);
    
    fval_ant = fval;
    time = [time toc];
    record = [record; fval];

end


tempo = sum(time);
disp('Tempo')
disp(tempo);

disp('M�nimo encontrado');
disp(fval);

x = min:0.01:max;
y = f(x);

vMin = y(1);
[a b] = size(y);
for i = 2:b
    if y(i) < vMin
        vMin = y(i);
    end
end

disp('M�nimo real');
disp(vMin);


subplot(3,2,1);
plot(record,'.');
title('convergencia do valor da fun��o');

subplot(2,2,2);
plot(x,y);
title('fun��o avaliada');

valorPopulacao = getValorCromossomo(populacao,min,max);

subplot(2,2,3);
plot(valorPopulacao,f(valorPopulacao),'*');
title('Distribuicao da popula��o na ultima itera��o');

subplot(2,2,4);
plot(time);
title('Tempo de cada itera��o');


