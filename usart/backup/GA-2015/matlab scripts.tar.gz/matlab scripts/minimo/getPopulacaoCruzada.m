%sorteio da roleta simples
function [pais plebe] = getPopulacaoCruzada(populacao,txCrossover)
        
    [N l] = size(populacao);
    
    tam = ceil(N*txCrossover);
    pais = [];
    for i = 1:tam
        pais = [pais; populacao(i,:)];
    end
    
    plebe = [];
    for i = tam + 1 : N
        plebe = [plebe; populacao(i,:)];
    end      
    
    pais = efetuaCrossover(pais);    
end