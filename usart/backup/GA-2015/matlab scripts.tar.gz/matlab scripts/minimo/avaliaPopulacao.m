function minimo = avaliaPopulacao(populacao,min,max)
    [N l] = size(populacao);
    valorCromossomo = getValorCromossomo(populacao,min,max);
    
    minimo = f(valorCromossomo(1));
    for i = 2:N
        val = f(valorCromossomo(i));
        if val < minimo
            minimo = val;
        end
    end 
end