function y = f(x)
    %y = x.*sin(x.*5);
    %y = abs(x.*sin(10./x));
    %y = exp(-1*x)*sin(x);    
    y = -1*(x+1)*(x-7);
    %y = tan(x);
    
end