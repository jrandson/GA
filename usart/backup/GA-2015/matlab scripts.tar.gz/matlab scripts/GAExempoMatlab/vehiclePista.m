function [thetaTemp,s,sAux]=vehiclePista(xAtual,sAuxAnt,tAnt,tAtual,vtheta,d)
    
    Tspan = [tAnt tAtual];
    IC = sAuxAnt;
    [aa, sTemp]=ode45(@(t,sAux) fdist(t,sAux,xAtual),Tspan,IC);
    sAux = sTemp(end);
    
 
    
    thetaTemp = vtheta(sum(sAux>=d));
    s = sAux/cos(thetaTemp);
end

function sAuxdot=fdist(t,sAux,x)
    sAuxdot = x;
end


