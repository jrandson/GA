function paisSelecionados = selecionaPais(populacao,min,max)
        
    [N l] = size(populacao);
    paisSelecionados = zeros(N,l);
    
    valorCromossomo = encontraValorCromossomo(populacao,min,max);
    [somaAptidao aptidao] = calculaAptidao(valorCromossomo);
    
    qtdAgulhas = 4;
    agulhas = zeros(qtdAgulhas,1);
    soma = rand()*somaAptidao;
    agulhas(1) = soma;
    div = somaAptidao/qtdAgulhas;
    for k = 2:qtdAgulhas
        soma = soma + div;
        if soma > somaAptidao
            soma = soma - somaAptidao;
        end
        agulhas(k) = soma;
    end
    
    for i = 1:4:N
        for k = 1:qtdAgulhas
            limiteCrm = agulhas(k);
            aptidaoAcumulada = 0;
            crm = populacao(1,:);
            for j = 1:N
                aptidaoAcumulada = aptidaoAcumulada + aptidao(j);
                if aptidaoAcumulada > limiteCrm
                    crm = populacao(j,:);
                    break;
                end
            end
            paisSelecionados(i+k-1,:) = crm;
        end
    end    
end