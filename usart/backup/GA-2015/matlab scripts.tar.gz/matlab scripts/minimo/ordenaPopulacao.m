function [populacao_out]  = ordenaPopulacao(populacao,min,max)
    
    valorCromossomo = getValorCromossomo(populacao,min,max);
    
    aptidao = calculaAptidao(valorCromossomo);
    
    [N l] = size(aptidao);  
    
    for i = 1:N
        for j = i+1:N
            if aptidao(j) < aptidao(i)
                aux = aptidao(i);
                aptidao(i) = aptidao(j);
                aptidao(j) = aux;
                
                %reajusta a ordem da populacao
                row = populacao(i,:);
                populacao(i,:) = populacao(j,:);
                populacao(j,:) = row;                
            end            
        end    
    end
    
    populacao_out = populacao;  
    
end